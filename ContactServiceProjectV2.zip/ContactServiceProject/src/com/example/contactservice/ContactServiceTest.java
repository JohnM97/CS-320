package com.example.contactservice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    void setup() {
        contactService = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("1234567890"));
    }

    @Test
    void testAddDuplicateContact() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact));
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        assertNull(contactService.getContact("1234567890"));
    }

    @Test
    void testUpdateContactNameById() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactNameById("1234567890", "Jane");
        assertEquals("Jane", contactService.getContact("1234567890").getFirstName());
    }

    @Test
    void testUpdateContactLastNameById() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactLastNameById("1234567890", "Smith");
        assertEquals("Smith", contactService.getContact("1234567890").getLastName());
    }

    @Test
    void testUpdateContactPhoneById() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactPhoneById("1234567890", "0987654321");
        assertEquals("0987654321", contactService.getContact("1234567890").getPhone());
    }

    @Test
    void testUpdateContactAddressById() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactAddressById("1234567890", "456 Elm St");
        assertEquals("456 Elm St", contactService.getContact("1234567890").getAddress());
    }
}
