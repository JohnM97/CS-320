package com.example.contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactTest {

    @Test
    void testCreateContactSuccess() {
        Contact contact = new Contact("123456", "Omar", "Toledo", "1234567890", "123 Main St");
        assertNotNull(contact);
        assertEquals("123456", contact.getContactId());
        assertEquals("Omar", contact.getFirstName());
        assertEquals("Toledo", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    void testCreateContactContactIdFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Omar", "Toledo", "1234567890", "123 Main St");
        });
    }

    @Test
    void testCreateContactFirstNameFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Omarrrrrrrrrr", "Toledo", "1234567890", "123 Main St");
        });
    }

    @Test
    void testCreateContactLastNameFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Omar", "Toledoooooo", "1234567890", "123 Main St");
        });
    }

    @Test
    void testCreateContactPhoneFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Omar", "Toledo", "123456789", "123 Main St");
        });
    }

    @Test
    void testCreateContactAddressFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Omar", "Toledo", "1234567890", "123456789012345678901234567890123");
        });
    }
}
